import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import smtplib
import ssl
import sys
from datetime import date, datetime, timedelta, timezone
from email.message import EmailMessage
from email.utils import parseaddr
from calendar import monthrange
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse


ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / "public"
DATA = ROOT / "data"
DATABASE = DATA / "farmacia.sqlite3"
SESSION_DAYS = 8
COOKIE_NAME = "farmacia_session"
ROLES = {"Administrador", "Enfermeiro", "Funcionário da Farmácia", "Consulta"}
TRANSFER_PENDING = "Pendente de Recebimento"
TRANSFER_RECEIVED = "Recebida"
TRANSFER_DIVERGENCE = "Divergência"
TRANSFER_REFUSED = "Recusada"
TRANSFER_CANCELLED = "Cancelada"
TRANSFER_REVERSED = "Estornada"


class ApiError(Exception):
    def __init__(self, status, message):
        self.status = status
        self.message = message


def connect_db():
    DATA.mkdir(exist_ok=True)
    db = sqlite3.connect(DATABASE, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    db.execute("PRAGMA busy_timeout = 10000")
    return db


def password_hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1)
    return salt.hex() + ":" + digest.hex()


def verify_password(password, encoded):
    try:
        salt_hex, expected = encoded.split(":", 1)
        actual = hashlib.scrypt(password.encode("utf-8"), salt=bytes.fromhex(salt_hex), n=2**14, r=8, p=1)
        return hmac.compare_digest(actual.hex(), expected)
    except (ValueError, TypeError):
        return False


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def initialize_db():
    db = connect_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS units (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL UNIQUE,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL DEFAULT '',
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('Administrador','Enfermeiro','Funcionário da Farmácia','Consulta')),
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS user_units (
            user_id INTEGER NOT NULL REFERENCES users(id),
            unit_id INTEGER NOT NULL REFERENCES units(id),
            PRIMARY KEY(user_id, unit_id)
        );
        CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY,
            csrf_token TEXT NOT NULL,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS medicines (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            active_ingredient TEXT NOT NULL DEFAULT '',
            concentration TEXT NOT NULL DEFAULT '',
            dosage_form TEXT NOT NULL DEFAULT '',
            presentation TEXT NOT NULL DEFAULT '',
            unit TEXT NOT NULL DEFAULT 'unidade',
            package_quantity REAL,
            package_unit TEXT NOT NULL DEFAULT '',
            stock_unit TEXT NOT NULL DEFAULT 'Unidade',
            administration_route TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT 'Geral',
            code TEXT NOT NULL UNIQUE,
            manufacturer_barcode TEXT NOT NULL DEFAULT '',
            minimum_stock INTEGER NOT NULL DEFAULT 0 CHECK(minimum_stock >= 0),
            notes TEXT NOT NULL DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS lots (
            id INTEGER PRIMARY KEY,
            unit_id INTEGER NOT NULL REFERENCES units(id),
            medicine_id INTEGER NOT NULL REFERENCES medicines(id),
            lot_number TEXT NOT NULL,
            internal_code TEXT NOT NULL UNIQUE,
            manufacture_date TEXT,
            expiration_date TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0),
            created_at TEXT NOT NULL,
            UNIQUE(unit_id, medicine_id, lot_number),
            UNIQUE(id, unit_id)
        );
        CREATE TABLE IF NOT EXISTS movements (
            id INTEGER PRIMARY KEY,
            unit_id INTEGER NOT NULL REFERENCES units(id),
            medicine_id INTEGER NOT NULL REFERENCES medicines(id),
            lot_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL REFERENCES users(id),
            kind TEXT NOT NULL CHECK(kind IN ('Entrada','Saída','Ajuste')),
            quantity INTEGER NOT NULL CHECK(quantity > 0),
            stock_before INTEGER NOT NULL,
            stock_after INTEGER NOT NULL,
            reason TEXT NOT NULL DEFAULT '',
            destination TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL DEFAULT '',
            document TEXT NOT NULL DEFAULT '',
            responsible TEXT NOT NULL DEFAULT '',
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(lot_id, unit_id) REFERENCES lots(id, unit_id)
        );
        CREATE TABLE IF NOT EXISTS inventory_counts (
            id INTEGER PRIMARY KEY,
            unit_id INTEGER NOT NULL REFERENCES units(id),
            lot_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL REFERENCES users(id),
            system_quantity INTEGER NOT NULL,
            counted_quantity INTEGER NOT NULL CHECK(counted_quantity >= 0),
            difference INTEGER NOT NULL,
            reason TEXT NOT NULL,
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(lot_id, unit_id) REFERENCES lots(id, unit_id)
        );
        CREATE TABLE IF NOT EXISTS transfers (
            id INTEGER PRIMARY KEY,
            origin_unit_id INTEGER NOT NULL REFERENCES units(id),
            destination_unit_id INTEGER NOT NULL REFERENCES units(id),
            medicine_id INTEGER NOT NULL REFERENCES medicines(id),
            origin_lot_id INTEGER NOT NULL REFERENCES lots(id),
            destination_lot_id INTEGER REFERENCES lots(id),
            lot_number TEXT NOT NULL,
            expiration_date TEXT NOT NULL,
            quantity_sent INTEGER NOT NULL CHECK(quantity_sent > 0),
            quantity_received INTEGER CHECK(quantity_received >= 0),
            status TEXT NOT NULL CHECK(status IN ('Pendente de Recebimento','Recebida','Divergência','Recusada','Cancelada','Estornada')),
            responsible TEXT NOT NULL DEFAULT '',
            notes TEXT NOT NULL DEFAULT '',
            created_by INTEGER NOT NULL REFERENCES users(id),
            created_at TEXT NOT NULL,
            refused_by INTEGER REFERENCES users(id),
            refused_at TEXT,
            refusal_reason TEXT NOT NULL DEFAULT '',
            received_by INTEGER REFERENCES users(id),
            received_at TEXT,
            discrepancy_reported_by INTEGER REFERENCES users(id),
            discrepancy_reported_at TEXT,
            discrepancy_reason TEXT NOT NULL DEFAULT '',
            discrepancy_notes TEXT NOT NULL DEFAULT '',
            resolved_by INTEGER REFERENCES users(id),
            resolved_at TEXT,
            resolution_reason TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS transfer_events (
            id INTEGER PRIMARY KEY,
            transfer_id INTEGER NOT NULL REFERENCES transfers(id),
            event_type TEXT NOT NULL,
            status TEXT NOT NULL,
            user_id INTEGER NOT NULL REFERENCES users(id),
            reason TEXT NOT NULL DEFAULT '',
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_lots_unit_expiry ON lots(unit_id, expiration_date);
        CREATE INDEX IF NOT EXISTS idx_movements_unit_date ON movements(unit_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_movements_medicine ON movements(medicine_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
        CREATE INDEX IF NOT EXISTS idx_transfers_destination_status ON transfers(destination_unit_id, status, created_at);
        CREATE INDEX IF NOT EXISTS idx_transfers_origin_status ON transfers(origin_unit_id, status, created_at);
    """)
    user_columns = {row["name"] for row in db.execute("PRAGMA table_info(users)")}
    if "email" not in user_columns:
        db.execute("ALTER TABLE users ADD COLUMN email TEXT NOT NULL DEFAULT ''")
    medicine_columns = {row["name"] for row in db.execute("PRAGMA table_info(medicines)")}
    migrations = {
        "package_quantity": "ALTER TABLE medicines ADD COLUMN package_quantity REAL",
        "package_unit": "ALTER TABLE medicines ADD COLUMN package_unit TEXT NOT NULL DEFAULT ''",
        "stock_unit": "ALTER TABLE medicines ADD COLUMN stock_unit TEXT NOT NULL DEFAULT 'Unidade'",
        "administration_route": "ALTER TABLE medicines ADD COLUMN administration_route TEXT NOT NULL DEFAULT ''",
    }
    for column, statement in migrations.items():
        if column not in medicine_columns:
            db.execute(statement)
    if "stock_unit" not in medicine_columns:
        db.execute("""UPDATE medicines SET stock_unit = CASE lower(trim(unit))
            WHEN 'cx' THEN 'Caixa' WHEN 'caixa' THEN 'Caixa'
            WHEN 'un' THEN 'Unidade' WHEN 'unidade' THEN 'Unidade'
            WHEN 'blister' THEN 'Blister' WHEN 'cartela' THEN 'Cartela'
            WHEN 'frasco' THEN 'Frasco' WHEN 'ampola' THEN 'Ampola'
            WHEN 'bisnaga' THEN 'Bisnaga' WHEN 'sachê' THEN 'Sachê'
            ELSE COALESCE(NULLIF(trim(unit), ''), 'Unidade') END""")
    if not db.execute("SELECT 1 FROM units LIMIT 1").fetchone():
        db.execute("INSERT INTO units(name, created_at) VALUES (?, ?)", ("USF Santa Maria do Bacuri", now_iso()))
    admin_username = os.environ.get("FARMACIA_ADMIN_USERNAME", "admin")
    admin_password = os.environ.get("FARMACIA_ADMIN_PASSWORD") or "Admin@123456"
    existing_admin = db.execute("SELECT id, username, password_hash FROM users WHERE username = ?", (admin_username,)).fetchone()

    if existing_admin:
        db.execute("UPDATE users SET password_hash = ?, full_name = COALESCE(full_name, 'Administrador da UBS') WHERE username = ?",
                   (password_hash(admin_password), admin_username))
        print(f"\nCredenciais do administrador ajustadas. Usuário: {admin_username} | Senha: {admin_password}\n", file=sys.stderr)
    else:
        unit_id = db.execute("SELECT id FROM units ORDER BY id LIMIT 1").fetchone()["id"]
        cursor = db.execute(
            "INSERT INTO users(username, full_name, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)",
            (admin_username, "Administrador da UBS", password_hash(admin_password), "Administrador", now_iso()),
        )
        db.execute("INSERT INTO user_units(user_id, unit_id) VALUES (?, ?)", (cursor.lastrowid, unit_id))
        print(f"\nConta inicial criada. Usuário: {admin_username} | Senha: {admin_password}\n", file=sys.stderr)
    db.commit()
    db.close()


def clean_text(value, label, limit=240, required=False):
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ApiError(400, f"Campo inválido: {label}.")
    value = value.strip()
    if required and not value:
        raise ApiError(400, f"Informe {label}.")
    if len(value) > limit:
        raise ApiError(400, f"{label} excede o limite de {limit} caracteres.")
    return value


def positive_int(value, label, allow_zero=False):
    try:
        number = int(value)
    except (TypeError, ValueError):
        raise ApiError(400, f"{label} deve ser um número inteiro.")
    if number < (0 if allow_zero else 1) or number > 2_000_000_000:
        raise ApiError(400, f"{label} fora do intervalo permitido.")
    return number


def checked_date(value, label):
    try:
        parsed = date.fromisoformat(value)
    except (TypeError, ValueError):
        raise ApiError(400, f"{label} deve estar no formato AAAA-MM-DD.")
    return parsed.isoformat()


def can_manage(user):
    return user["role"] in ("Administrador", "Enfermeiro", "Funcionário da Farmácia")


class PharmacyHandler(BaseHTTPRequestHandler):
    server_version = "FarmaciaUBS/1.0"

    def log_message(self, _format, *_args):
        return

    def send_json(self, status, payload, headers=None):
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
        if headers:
            for key, value in headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(encoded)

    def send_error_json(self, error):
        self.send_json(error.status, {"error": error.message})

    def read_json(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(400, "Cabeçalho de tamanho inválido.")
        if length < 1 or length > 1_000_000:
            raise ApiError(413 if length > 1_000_000 else 400, "Corpo da solicitação inválido.")
        if "application/json" not in self.headers.get("Content-Type", "").lower():
            raise ApiError(415, "Use conteúdo JSON.")
        try:
            payload = json.loads(self.rfile.read(length))
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ApiError(400, "JSON inválido.")
        if not isinstance(payload, dict):
            raise ApiError(400, "O corpo deve ser um objeto JSON.")
        return payload

    def cookie_value(self):
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
            return cookie[COOKIE_NAME].value if COOKIE_NAME in cookie else ""
        except Exception:
            return ""

    def get_user(self):
        token = self.cookie_value()
        if not token:
            raise ApiError(401, "Faça login para continuar.")
        db = connect_db()
        row = db.execute("""
            SELECT u.id, u.username, u.full_name, u.role, s.csrf_token, s.expires_at
            FROM sessions s JOIN users u ON u.id = s.user_id
            WHERE s.token_hash = ? AND u.active = 1
        """, (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
        if not row or row["expires_at"] <= now_iso():
            if row:
                db.execute("DELETE FROM sessions WHERE token_hash = ?", (hashlib.sha256(token.encode()).hexdigest(),))
                db.commit()
            db.close()
            raise ApiError(401, "Sessão expirada. Entre novamente.")
        units = db.execute("""
            SELECT un.id, un.name FROM units un
            JOIN user_units uu ON uu.unit_id = un.id WHERE uu.user_id = ? ORDER BY un.name
        """, (row["id"],)).fetchall()
        db.close()
        if row["role"] == "Administrador":
            db = connect_db()
            units = db.execute("SELECT id, name FROM units ORDER BY name").fetchall()
            db.close()
        return {**dict(row), "units": [dict(unit) for unit in units]}

    def require_csrf(self, user):
        origin = self.headers.get("Origin")
        if origin:
            expected = f"http://{self.headers.get('Host')}"
            if origin.rstrip("/") != expected.rstrip("/"):
                raise ApiError(403, "Origem não autorizada.")
        supplied = self.headers.get("X-CSRF-Token", "")
        if not hmac.compare_digest(supplied, user["csrf_token"]):
            raise ApiError(403, "Token de segurança inválido. Atualize a página e tente novamente.")

    def get_unit_id(self, db, user):
        units = user["units"]
        if not units:
            raise ApiError(403, "Sua conta não tem unidades vinculadas.")
        raw = self.headers.get("X-Unit-ID", "")
        unit_id = positive_int(raw, "Unidade") if raw else units[0]["id"]
        if user["role"] != "Administrador" and unit_id not in {unit["id"] for unit in units}:
            raise ApiError(403, "Você não tem acesso a esta unidade.")
        if not db.execute("SELECT 1 FROM units WHERE id = ?", (unit_id,)).fetchone():
            raise ApiError(404, "Unidade não encontrada.")
        return unit_id

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/", "/index.html", "/app.js", "/app.css"):
            filename = "index.html" if path in ("/", "/index.html") else path[1:]
            content_type = "text/html; charset=utf-8" if filename.endswith(".html") else "text/javascript; charset=utf-8" if filename.endswith(".js") else "text/css; charset=utf-8"
            try:
                content = (PUBLIC / filename).read_bytes()
            except OSError:
                self.send_json(404, {"error": "Arquivo não encontrado."})
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(content)
            return
        if not path.startswith("/api/"):
            self.send_json(404, {"error": "Rota não encontrada."})
            return
        db = None
        try:
            user = self.get_user()
            db = connect_db()
            unit_id = self.get_unit_id(db, user)
            result = self.api_get(path, db, user, unit_id)
            db.close()
            self.send_json(200, result)
        except ApiError as error:
            self.send_error_json(error)
        except Exception:
            self.send_json(500, {"error": "Erro interno. Consulte o log do servidor."})
        finally:
            if db is not None:
                db.close()

    def api_get(self, path, db, user, unit_id):
        if path == "/api/session":
            return {"user": {"id": user["id"], "username": user["username"], "name": user["full_name"], "role": user["role"]}, "units": user["units"], "csrfToken": user["csrf_token"], "activeUnitId": unit_id}
        if path == "/api/users":
            if user["role"] != "Administrador":
                raise ApiError(403, "Apenas administradores podem gerenciar usuários.")
            return {"items": [dict(row) for row in db.execute("""
                SELECT u.id, u.username, u.full_name, u.email, u.role, u.active, u.created_at,
                       COALESCE(GROUP_CONCAT(un.name, ' | '), '') AS unit_names,
                       COALESCE(GROUP_CONCAT(un.id, ','), '') AS unit_ids
                FROM users u
                LEFT JOIN user_units uu ON uu.user_id = u.id
                LEFT JOIN units un ON un.id = uu.unit_id
                GROUP BY u.id ORDER BY u.active DESC, u.full_name
            """).fetchall()], "units": [dict(row) for row in db.execute("SELECT id, name FROM units ORDER BY name").fetchall()]}
        if path == "/api/transfers":
            items = self.list_transfers(db, unit_id)
            pending = sum(item["destination_unit_id"] == unit_id and item["status"] == TRANSFER_PENDING for item in items)
            return {"items": items, "pending_receipts": pending}
        if path == "/api/reports/movements":
            return self.movement_report(db, unit_id)
        if path == "/api/medicines":
            query = "%" + parse_qs(urlparse(self.path).query).get("q", [""])[0].strip() + "%"
            return {"items": [dict(row) for row in db.execute("""
                SELECT m.*, COALESCE(SUM(l.quantity), 0) AS stock
                FROM medicines m LEFT JOIN lots l ON l.medicine_id = m.id AND l.unit_id = ?
                WHERE m.active = 1 AND (m.name LIKE ? OR m.concentration LIKE ? OR m.dosage_form LIKE ? OR m.presentation LIKE ? OR m.stock_unit LIKE ? OR m.administration_route LIKE ? OR m.manufacturer_barcode LIKE ?)
                GROUP BY m.id ORDER BY m.name
            """, (unit_id, query, query, query, query, query, query, query)).fetchall()]}
        if path == "/api/lots":
            return {"items": [dict(row) for row in db.execute("""
                SELECT l.*, m.name AS medicine_name, m.concentration, m.dosage_form, m.presentation,
                       m.administration_route, m.manufacturer_barcode, m.stock_unit AS measure_unit,
                       m.minimum_stock, m.code AS medicine_code, u.name AS unit_name
                FROM lots l JOIN medicines m ON m.id = l.medicine_id JOIN units u ON u.id = l.unit_id
                WHERE l.unit_id = ? ORDER BY l.expiration_date, m.name
            """, (unit_id,)).fetchall()]}
        if path == "/api/movements":
            return {"items": [dict(row) for row in db.execute("""
                  SELECT mv.*, m.name AS medicine_name, m.concentration, m.dosage_form, m.presentation,
                      m.administration_route, m.manufacturer_barcode, m.stock_unit, l.lot_number, u.full_name AS user_name
                FROM movements mv JOIN medicines m ON m.id = mv.medicine_id
                JOIN lots l ON l.id = mv.lot_id JOIN users u ON u.id = mv.user_id
                WHERE mv.unit_id = ? ORDER BY mv.created_at DESC, mv.id DESC LIMIT 500
            """, (unit_id,)).fetchall()]}
        if path == "/api/alerts":
            return {"items": self.alerts(db, unit_id)}
        if path == "/api/inventory":
            return {"items": [dict(row) for row in db.execute("""
                SELECT l.id AS lot_id, l.lot_number, l.quantity AS system_quantity, l.expiration_date,
                       m.id AS medicine_id, m.name AS medicine_name, m.concentration, m.dosage_form, m.presentation,
                       m.administration_route, m.manufacturer_barcode, m.stock_unit AS measure_unit
                FROM lots l JOIN medicines m ON m.id = l.medicine_id
                WHERE l.unit_id = ? ORDER BY m.name, l.expiration_date
            """, (unit_id,)).fetchall()]}
        if path == "/api/dashboard":
            today = date.today()
            month_start = today.replace(day=1).isoformat()
            counts = db.execute("""
                SELECT COUNT(DISTINCT CASE WHEN m.active = 1 THEN m.id END) AS medicines,
                       COALESCE(SUM(l.quantity),0) AS units,
                       COUNT(DISTINCT CASE WHEN l.quantity = 0 THEN l.id END) AS empty_lots
                FROM medicines m LEFT JOIN lots l ON l.medicine_id = m.id AND l.unit_id = ?
            """, (unit_id,)).fetchone()
            month = db.execute("""
                SELECT kind, COALESCE(SUM(quantity),0) AS total FROM movements
                WHERE unit_id = ? AND substr(created_at,1,10) >= ? GROUP BY kind
            """, (unit_id, month_start)).fetchall()
            alerts = self.alerts(db, unit_id)
            pending_transfers = db.execute("SELECT COUNT(*) FROM transfers WHERE destination_unit_id=? AND status=?", (unit_id, TRANSFER_PENDING)).fetchone()[0]
            near = sum(item["type"] == "expiry" and item["days_remaining"] >= 0 for item in alerts)
            expired = sum(item["type"] == "expiry" and item["days_remaining"] < 0 for item in alerts)
            return {"summary": {**dict(counts), "low_stock": sum(item["type"] == "low_stock" for item in alerts), "expiring": near, "expired": expired,
                    "entries_month": next((row["total"] for row in month if row["kind"] == "Entrada"), 0),
                    "exits_month": next((row["total"] for row in month if row["kind"] == "Saída"), 0),
                    "alerts": len(alerts), "pending_transfers": pending_transfers}, "alerts": alerts[:8], "recent": [dict(row) for row in db.execute("""
                  SELECT mv.id, mv.kind, mv.quantity, mv.created_at, m.name AS medicine_name, m.concentration,
                      m.dosage_form, m.presentation, m.administration_route, m.stock_unit, l.lot_number
                FROM movements mv JOIN medicines m ON m.id=mv.medicine_id JOIN lots l ON l.id=mv.lot_id
                WHERE mv.unit_id=? ORDER BY mv.created_at DESC LIMIT 8
            """, (unit_id,)).fetchall()]}
        raise ApiError(404, "Rota não encontrada.")

    def list_transfers(self, db, unit_id):
        rows = db.execute("""
            SELECT t.*, origin.name AS origin_name, destination.name AS destination_name,
                   m.name AS medicine_name, m.concentration, m.dosage_form, m.presentation,
                   m.stock_unit, sender.full_name AS sender_name, receiver.full_name AS receiver_name,
                   reporter.full_name AS discrepancy_reporter_name, resolver.full_name AS resolver_name
            FROM transfers t
            JOIN units origin ON origin.id=t.origin_unit_id
            JOIN units destination ON destination.id=t.destination_unit_id
            JOIN medicines m ON m.id=t.medicine_id
            JOIN users sender ON sender.id=t.created_by
            LEFT JOIN users receiver ON receiver.id=t.received_by
            LEFT JOIN users reporter ON reporter.id=t.discrepancy_reported_by
            LEFT JOIN users resolver ON resolver.id=t.resolved_by
            WHERE t.origin_unit_id=? OR t.destination_unit_id=?
            ORDER BY CASE WHEN t.destination_unit_id=? AND t.status=? THEN 0 ELSE 1 END, t.created_at DESC, t.id DESC
        """, (unit_id, unit_id, unit_id, TRANSFER_PENDING)).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["events"] = [dict(event) for event in db.execute("""
                SELECT e.id, e.event_type, e.status, e.reason, e.notes, e.created_at, u.full_name AS user_name
                FROM transfer_events e JOIN users u ON u.id=e.user_id
                WHERE e.transfer_id=? ORDER BY e.created_at, e.id
            """, (item["id"],)).fetchall()]
            result.append(item)
        return result

    def record_transfer_event(self, db, transfer_id, event_type, status, user_id, reason="", notes=""):
        db.execute("""INSERT INTO transfer_events(transfer_id,event_type,status,user_id,reason,notes,created_at)
            VALUES(?,?,?,?,?,?,?)""", (transfer_id, event_type, status, user_id, reason, notes, now_iso()))

    def require_transfer_manager(self, user):
        if not can_manage(user):
            raise ApiError(403, "Seu perfil não pode gerenciar transferências.")

    def require_unit_access(self, user, unit_id):
        if user["role"] != "Administrador" and unit_id not in {unit["id"] for unit in user["units"]}:
            raise ApiError(403, "Você não tem acesso a esta unidade.")

    def load_transfer(self, db, transfer_id):
        transfer = db.execute("SELECT * FROM transfers WHERE id=?", (transfer_id,)).fetchone()
        if not transfer:
            raise ApiError(404, "Transferência não encontrada.")
        return transfer

    def create_transfer(self, db, user, active_unit_id, payload):
        self.require_transfer_manager(user)
        origin_unit_id = positive_int(payload.get("origin_unit_id"), "Unidade de origem")
        destination_unit_id = positive_int(payload.get("destination_unit_id"), "Unidade de destino")
        if origin_unit_id != active_unit_id:
            raise ApiError(403, "A unidade de origem deve ser a unidade atualmente selecionada.")
        self.require_unit_access(user, origin_unit_id)
        if destination_unit_id == origin_unit_id:
            raise ApiError(400, "A unidade de destino deve ser diferente da origem.")
        if not db.execute("SELECT 1 FROM units WHERE id=?", (destination_unit_id,)).fetchone():
            raise ApiError(404, "Unidade de destino não encontrada.")
        medicine_id = positive_int(payload.get("medicine_id"), "Medicamento")
        lot_id = positive_int(payload.get("lot_id"), "Lote")
        quantity = positive_int(payload.get("quantity"), "Quantidade")
        responsible = clean_text(payload.get("responsible"), "o responsável pela transferência", 180, True)
        notes = clean_text(payload.get("notes"), "observações", 1000)
        db.execute("BEGIN IMMEDIATE")
        lot = db.execute("""SELECT l.*, m.name AS medicine_name, m.stock_unit
            FROM lots l JOIN medicines m ON m.id=l.medicine_id
            WHERE l.id=? AND l.unit_id=? AND l.medicine_id=? AND m.active=1""",
            (lot_id, origin_unit_id, medicine_id)).fetchone()
        if not lot:
            raise ApiError(404, "Lote não encontrado na unidade de origem.")
        if lot["expiration_date"] < date.today().isoformat():
            raise ApiError(409, "Não é possível transferir um lote vencido.")
        if quantity > lot["quantity"]:
            raise ApiError(409, f"Estoque insuficiente no lote {lot['lot_number']}. Disponível: {lot['quantity']} {lot['stock_unit']}.")
        before, after = lot["quantity"], lot["quantity"] - quantity
        db.execute("UPDATE lots SET quantity=? WHERE id=?", (after, lot_id))
        cursor = db.execute("""INSERT INTO transfers(origin_unit_id,destination_unit_id,medicine_id,origin_lot_id,
            lot_number,expiration_date,quantity_sent,status,responsible,notes,created_by,created_at)
            VALUES(?,?,?,?,?,?,?, ?,?,?,?,?)""", (origin_unit_id, destination_unit_id, medicine_id, lot_id,
            lot["lot_number"], lot["expiration_date"], quantity, TRANSFER_PENDING, responsible, notes, user["id"], now_iso()))
        transfer_id = cursor.lastrowid
        destination_name = db.execute("SELECT name FROM units WHERE id=?", (destination_unit_id,)).fetchone()["name"]
        self.insert_movement(db, origin_unit_id, medicine_id, lot_id, user["id"], "Saída", quantity, before, after, {
            "reason": "Transferência entre unidades", "destination": destination_name,
            "document": f"TRF-{transfer_id:06d}", "responsible": responsible, "notes": notes
        })
        self.record_transfer_event(db, transfer_id, "Enviada", TRANSFER_PENDING, user["id"], notes=notes)
        db.commit()
        self.send_transfer_email(db, transfer_id)
        return {"id": transfer_id, "status": TRANSFER_PENDING, "quantity_sent": quantity, "stock_before": before,
                "stock_after": after, "stock_unit": lot["stock_unit"], "lot_number": lot["lot_number"],
                "expiration_date": lot["expiration_date"]}

    def send_transfer_email(self, db, transfer_id):
        host = os.environ.get("FARMACIA_SMTP_HOST", "").strip()
        sender = os.environ.get("FARMACIA_SMTP_FROM", "").strip()
        if not host or not sender:
            return
        row = db.execute("""SELECT t.*, origin.name AS origin_name, destination.name AS destination_name,
            m.name AS medicine_name, m.stock_unit FROM transfers t
            JOIN units origin ON origin.id=t.origin_unit_id JOIN units destination ON destination.id=t.destination_unit_id
            JOIN medicines m ON m.id=t.medicine_id WHERE t.id=?""", (transfer_id,)).fetchone()
        recipients = [item[0] for item in db.execute("""SELECT DISTINCT u.email FROM users u
            LEFT JOIN user_units uu ON uu.user_id=u.id WHERE u.active=1
            AND u.role IN ('Administrador','Enfermeiro','Funcionário da Farmácia') AND u.email<>''
            AND (u.role='Administrador' OR uu.unit_id=?)""",
            (row["destination_unit_id"],)).fetchall()]
        if not recipients:
            return
        message = EmailMessage()
        message["Subject"] = f"Transferência pendente de recebimento · TRF-{transfer_id:06d}"
        message["From"] = sender
        message["To"] = ", ".join(recipients)
        message.set_content(f"""Transferência pendente de recebimento

Origem: {row['origin_name']}
Destino: {row['destination_name']}
Medicamento: {row['medicine_name']}
Lote: {row['lot_number']}
Quantidade enviada: {row['quantity_sent']} {row['stock_unit']}
Validade: {date.fromisoformat(row['expiration_date']).strftime('%d/%m/%Y')}
Enviado por: {row['responsible']}
Data e hora: {row['created_at']}
Observações: {row['notes'] or '—'}
""")
        try:
            port = int(os.environ.get("FARMACIA_SMTP_PORT", "587"))
            with smtplib.SMTP(host, port, timeout=10) as client:
                client.ehlo()
                if os.environ.get("FARMACIA_SMTP_TLS", "1") != "0":
                    client.starttls(context=ssl.create_default_context())
                    client.ehlo()
                smtp_user = os.environ.get("FARMACIA_SMTP_USER", "")
                smtp_password = os.environ.get("FARMACIA_SMTP_PASSWORD", "")
                if smtp_user:
                    client.login(smtp_user, smtp_password)
                client.send_message(message)
        except (OSError, smtplib.SMTPException, ValueError) as error:
            print(f"Falha ao enviar notificação de transferência por e-mail: {error}", file=sys.stderr)

    def transfer_action(self, db, user, active_unit_id, path, payload):
        self.require_transfer_manager(user)
        parts = path.strip("/").split("/")
        if len(parts) != 3 or parts[0:2] != ["api", "transfers"]:
            raise ApiError(404, "Rota de transferência não encontrada.")
        transfer_id = positive_int(parts[2], "Transferência")
        action = clean_text(payload.get("action"), "a ação", 30, True)
        if action == "receber":
            return self.receive_transfer(db, user, active_unit_id, transfer_id)
        if action == "divergencia":
            return self.report_transfer_discrepancy(db, user, active_unit_id, transfer_id, payload)
        if action == "recusar":
            return self.refuse_transfer(db, user, active_unit_id, transfer_id, payload)
        if action == "cancelar":
            return self.cancel_transfer(db, user, active_unit_id, transfer_id, payload)
        if action == "resolver":
            return self.resolve_transfer(db, user, active_unit_id, transfer_id, payload)
        if action == "estornar":
            return self.refund_transfer(db, user, active_unit_id, transfer_id, payload)
        raise ApiError(400, "Ação de transferência inválida.")

    def receive_transfer(self, db, user, active_unit_id, transfer_id):
        db.execute("BEGIN IMMEDIATE")
        transfer = self.load_transfer(db, transfer_id)
        if transfer["destination_unit_id"] != active_unit_id:
            raise ApiError(403, "Somente a unidade de destino pode confirmar o recebimento.")
        self.require_unit_access(user, transfer["destination_unit_id"])
        if transfer["status"] != TRANSFER_PENDING:
            raise ApiError(409, "Esta transferência não está pendente de recebimento.")
        destination_lot_id = self.credit_transfer_destination(db, transfer, user, transfer["quantity_sent"])
        received_at = now_iso()
        db.execute("""UPDATE transfers SET status=?, quantity_received=quantity_sent, destination_lot_id=?,
            received_by=?, received_at=? WHERE id=?""",
            (TRANSFER_RECEIVED, destination_lot_id, user["id"], received_at, transfer_id))
        self.record_transfer_event(db, transfer_id, "Recebimento confirmado", TRANSFER_RECEIVED, user["id"])
        db.commit()
        return {"id": transfer_id, "status": TRANSFER_RECEIVED, "quantity_received": transfer["quantity_sent"]}

    def report_transfer_discrepancy(self, db, user, active_unit_id, transfer_id, payload):
        quantity_received = positive_int(payload.get("quantity_received"), "Quantidade recebida", allow_zero=True)
        reason = clean_text(payload.get("reason"), "o motivo da divergência", 500, True)
        notes = clean_text(payload.get("notes"), "observações", 1000)
        db.execute("BEGIN IMMEDIATE")
        transfer = self.load_transfer(db, transfer_id)
        if transfer["destination_unit_id"] != active_unit_id:
            raise ApiError(403, "Somente a unidade de destino pode informar divergência.")
        self.require_unit_access(user, transfer["destination_unit_id"])
        if transfer["status"] != TRANSFER_PENDING:
            raise ApiError(409, "Esta transferência não está pendente de recebimento.")
        if quantity_received == transfer["quantity_sent"]:
            raise ApiError(400, "A quantidade recebida corresponde ao envio. Use Confirmar recebimento.")
        reported_at = now_iso()
        db.execute("""UPDATE transfers SET status=?, quantity_received=?, discrepancy_reported_by=?,
            discrepancy_reported_at=?, discrepancy_reason=?, discrepancy_notes=? WHERE id=?""",
            (TRANSFER_DIVERGENCE, quantity_received, user["id"], reported_at, reason, notes, transfer_id))
        self.record_transfer_event(db, transfer_id, "Divergência informada", TRANSFER_DIVERGENCE, user["id"], reason, notes)
        db.commit()
        return {"id": transfer_id, "status": TRANSFER_DIVERGENCE, "quantity_sent": transfer["quantity_sent"],
                "quantity_received": quantity_received, "difference": transfer["quantity_sent"] - quantity_received}

    def refuse_transfer(self, db, user, active_unit_id, transfer_id, payload):
        reason = clean_text(payload.get("reason"), "a justificativa da recusa", 500, True)
        notes = clean_text(payload.get("notes"), "observações", 1000)
        db.execute("BEGIN IMMEDIATE")
        transfer = self.load_transfer(db, transfer_id)
        if transfer["destination_unit_id"] != active_unit_id:
            raise ApiError(403, "Somente a unidade de destino pode recusar o recebimento.")
        self.require_unit_access(user, transfer["destination_unit_id"])
        if transfer["status"] != TRANSFER_PENDING:
            raise ApiError(409, "Esta transferência não está pendente de recebimento.")
        refused_at = now_iso()
        db.execute("UPDATE transfers SET status=?, refused_by=?, refused_at=?, refusal_reason=?, discrepancy_notes=? WHERE id=?",
            (TRANSFER_REFUSED, user["id"], refused_at, reason, notes, transfer_id))
        self.record_transfer_event(db, transfer_id, "Recebimento recusado", TRANSFER_REFUSED, user["id"], reason, notes)
        db.commit()
        return {"id": transfer_id, "status": TRANSFER_REFUSED}

    def cancel_transfer(self, db, user, active_unit_id, transfer_id, payload):
        reason = clean_text(payload.get("reason"), "o motivo do cancelamento", 500, True)
        db.execute("BEGIN IMMEDIATE")
        transfer = self.load_transfer(db, transfer_id)
        if transfer["origin_unit_id"] != active_unit_id:
            raise ApiError(403, "Somente a unidade de origem pode cancelar a transferência.")
        self.require_unit_access(user, transfer["origin_unit_id"])
        if transfer["status"] != TRANSFER_PENDING:
            raise ApiError(409, "Somente transferências pendentes podem ser canceladas.")
        self.restore_transfer_origin(db, transfer, user, "Cancelamento de transferência", reason)
        resolved_at = now_iso()
        db.execute("UPDATE transfers SET status=?, resolved_by=?, resolved_at=?, resolution_reason=? WHERE id=?",
            (TRANSFER_CANCELLED, user["id"], resolved_at, reason, transfer_id))
        self.record_transfer_event(db, transfer_id, "Transferência cancelada", TRANSFER_CANCELLED, user["id"], reason)
        db.commit()
        return {"id": transfer_id, "status": TRANSFER_CANCELLED}

    def resolve_transfer(self, db, user, active_unit_id, transfer_id, payload):
        decision = clean_text(payload.get("decision"), "a decisão", 20, True)
        if decision == "estornar":
            return self.refund_transfer(db, user, active_unit_id, transfer_id, payload)
        if decision != "receber":
            raise ApiError(400, "Escolha receber a quantidade informada ou estornar a transferência.")
        reason = clean_text(payload.get("reason"), "o motivo da resolução", 500, True)
        notes = clean_text(payload.get("notes"), "observações", 1000)
        db.execute("BEGIN IMMEDIATE")
        transfer = self.load_transfer(db, transfer_id)
        if transfer["origin_unit_id"] != active_unit_id:
            raise ApiError(403, "Somente a unidade de origem pode resolver a divergência.")
        self.require_unit_access(user, transfer["origin_unit_id"])
        if transfer["status"] != TRANSFER_DIVERGENCE or transfer["quantity_received"] is None:
            raise ApiError(409, "A transferência não possui divergência pendente de resolução.")
        if transfer["quantity_received"] == 0:
            raise ApiError(400, "Não há quantidade recebida para dar entrada. Estorne a transferência após conferir a devolução.")
        destination_lot_id = self.credit_transfer_destination(db, transfer, user, transfer["quantity_received"], reason)
        resolved_at = now_iso()
        db.execute("""UPDATE transfers SET status=?, destination_lot_id=?, received_by=discrepancy_reported_by,
            received_at=discrepancy_reported_at, resolved_by=?, resolved_at=?, resolution_reason=? WHERE id=?""",
            (TRANSFER_RECEIVED, destination_lot_id, user["id"], resolved_at, reason, transfer_id))
        event_notes = "; ".join(part for part in (transfer["discrepancy_notes"], notes) if part)
        self.record_transfer_event(db, transfer_id, "Divergência resolvida: quantidade recebida aceita", TRANSFER_RECEIVED, user["id"], reason, event_notes)
        db.commit()
        return {"id": transfer_id, "status": TRANSFER_RECEIVED, "quantity_received": transfer["quantity_received"]}

    def refund_transfer(self, db, user, active_unit_id, transfer_id, payload):
        reason = clean_text(payload.get("reason"), "a justificativa do estorno", 500, True)
        db.execute("BEGIN IMMEDIATE")
        transfer = self.load_transfer(db, transfer_id)
        if transfer["origin_unit_id"] != active_unit_id:
            raise ApiError(403, "Somente a unidade de origem pode estornar a transferência.")
        self.require_unit_access(user, transfer["origin_unit_id"])
        if transfer["status"] not in (TRANSFER_REFUSED, TRANSFER_DIVERGENCE):
            raise ApiError(409, "Somente transferências recusadas ou divergentes podem ser estornadas.")
        self.restore_transfer_origin(db, transfer, user, "Estorno de transferência", reason)
        resolved_at = now_iso()
        db.execute("UPDATE transfers SET status=?, resolved_by=?, resolved_at=?, resolution_reason=? WHERE id=?",
            (TRANSFER_REVERSED, user["id"], resolved_at, reason, transfer_id))
        self.record_transfer_event(db, transfer_id, "Estorno confirmado e devolvido à origem", TRANSFER_REVERSED, user["id"], reason)
        db.commit()
        return {"id": transfer_id, "status": TRANSFER_REVERSED}

    def restore_transfer_origin(self, db, transfer, user, movement_reason, reason):
        lot = db.execute("SELECT * FROM lots WHERE id=? AND unit_id=?", (transfer["origin_lot_id"], transfer["origin_unit_id"])).fetchone()
        if not lot:
            raise ApiError(409, "O lote original não existe mais na unidade de origem.")
        before = lot["quantity"]
        after = before + transfer["quantity_sent"]
        db.execute("UPDATE lots SET quantity=? WHERE id=?", (after, lot["id"]))
        origin_name = db.execute("SELECT name FROM units WHERE id=?", (transfer["origin_unit_id"],)).fetchone()["name"]
        self.insert_movement(db, transfer["origin_unit_id"], transfer["medicine_id"], lot["id"], user["id"], "Entrada",
            transfer["quantity_sent"], before, after, {"reason": movement_reason, "source": "Unidade de destino",
            "document": f"TRF-{transfer['id']:06d}", "responsible": user["full_name"], "notes": f"{origin_name}: {reason}"})

    def credit_transfer_destination(self, db, transfer, user, quantity, reason=""):
        if transfer["expiration_date"] < date.today().isoformat():
            raise ApiError(409, "O lote venceu durante o transporte e não pode entrar no estoque. Recuse ou resolva com estorno.")
        existing = db.execute("""SELECT * FROM lots WHERE unit_id=? AND medicine_id=? AND lot_number=?""",
            (transfer["destination_unit_id"], transfer["medicine_id"], transfer["lot_number"])).fetchone()
        if existing and existing["expiration_date"] != transfer["expiration_date"]:
            raise ApiError(409, "Já existe um lote com o mesmo número e outra validade no destino.")
        if existing:
            destination_lot_id = existing["id"]
            before = existing["quantity"]
            after = before + quantity
            db.execute("UPDATE lots SET quantity=? WHERE id=?", (after, destination_lot_id))
        else:
            manufacture_date = db.execute("SELECT manufacture_date FROM lots WHERE id=?", (transfer["origin_lot_id"],)).fetchone()["manufacture_date"]
            cursor = db.execute("""INSERT INTO lots(unit_id,medicine_id,lot_number,internal_code,manufacture_date,
                expiration_date,quantity,created_at) VALUES(?,?,?,?,?,?,0,?)""",
                (transfer["destination_unit_id"], transfer["medicine_id"], transfer["lot_number"], "PENDING",
                 manufacture_date, transfer["expiration_date"], now_iso()))
            destination_lot_id = cursor.lastrowid
            internal_code = f"UBS-{transfer['medicine_id']:06d}-{destination_lot_id:06d}"
            before, after = 0, quantity
            db.execute("UPDATE lots SET internal_code=?, quantity=? WHERE id=?", (internal_code, after, destination_lot_id))
        if existing:
            after = before + quantity
        destination_name = db.execute("SELECT name FROM units WHERE id=?", (transfer["destination_unit_id"],)).fetchone()["name"]
        origin_name = db.execute("SELECT name FROM units WHERE id=?", (transfer["origin_unit_id"],)).fetchone()["name"]
        notes = "; ".join(part for part in (transfer["notes"], transfer["discrepancy_reason"], transfer["discrepancy_notes"], reason) if part)
        self.insert_movement(db, transfer["destination_unit_id"], transfer["medicine_id"], destination_lot_id, user["id"], "Entrada",
            quantity, before, after, {"reason": "Recebimento de transferência", "source": origin_name,
            "destination": destination_name, "document": f"TRF-{transfer['id']:06d}",
            "responsible": user["full_name"], "notes": notes})
        return destination_lot_id

    def movement_report(self, db, unit_id):
        query = parse_qs(urlparse(self.path).query)
        period = query.get("period", ["weekly"])[0]
        if period not in ("weekly", "monthly"):
            raise ApiError(400, "O período deve ser semanal ou mensal.")
        raw_reference = query.get("date", [date.today().isoformat()])[0]
        try:
            reference = date.fromisoformat(raw_reference)
        except (TypeError, ValueError):
            raise ApiError(400, "Informe uma data de referência válida no formato AAAA-MM-DD.")
        if period == "weekly":
            start = reference - timedelta(days=reference.weekday())
            end = start + timedelta(days=6)
            label = "Semanal"
        else:
            start = date(reference.year, reference.month, 1)
            end = date(reference.year, reference.month, monthrange(reference.year, reference.month)[1])
            label = "Mensal"
        rows = [dict(row) for row in db.execute("""
            SELECT m.id AS medicine_id, m.name AS medicine_name, m.concentration,
                   m.dosage_form, m.presentation, m.administration_route, m.stock_unit,
                   COALESCE(SUM(CASE WHEN mv.kind='Entrada' THEN mv.quantity ELSE 0 END),0) AS entries,
                   COALESCE(SUM(CASE WHEN mv.kind='Saída' THEN mv.quantity ELSE 0 END),0) AS exits,
                   COALESCE(SUM(CASE WHEN mv.kind='Ajuste' THEN mv.quantity ELSE 0 END),0) AS adjustments,
                   SUM(CASE WHEN mv.kind='Entrada' THEN 1 ELSE 0 END) AS entry_records,
                   SUM(CASE WHEN mv.kind='Saída' THEN 1 ELSE 0 END) AS exit_records
            FROM movements mv JOIN medicines m ON m.id=mv.medicine_id
            WHERE mv.unit_id=? AND substr(mv.created_at,1,10) BETWEEN ? AND ?
            GROUP BY m.id
            HAVING SUM(CASE WHEN mv.kind IN ('Entrada','Saída','Ajuste') THEN 1 ELSE 0 END)>0
            ORDER BY m.name COLLATE NOCASE
        """, (unit_id, start.isoformat(), end.isoformat())).fetchall()]
        totals = {
            "entries": sum(row["entries"] for row in rows),
            "exits": sum(row["exits"] for row in rows),
            "adjustments": sum(row["adjustments"] for row in rows),
            "entry_records": sum(row["entry_records"] for row in rows),
            "exit_records": sum(row["exit_records"] for row in rows),
        }
        unit_name = db.execute("SELECT name FROM units WHERE id=?", (unit_id,)).fetchone()["name"]
        return {"period": period, "period_label": label, "reference_date": reference.isoformat(),
                "start_date": start.isoformat(), "end_date": end.isoformat(), "unit": unit_name,
                "items": rows, "totals": totals}

    def alerts(self, db, unit_id):
        today = date.today()
        lots = db.execute("""
                 SELECT l.id, l.lot_number, l.quantity, l.expiration_date, m.id AS medicine_id,
                     m.name AS medicine_name, m.concentration, m.dosage_form, m.presentation,
                     m.administration_route, m.minimum_stock, m.stock_unit
            FROM lots l JOIN medicines m ON m.id = l.medicine_id
            WHERE l.unit_id = ? AND l.quantity > 0 AND l.expiration_date <= ?
            ORDER BY l.expiration_date
        """, (unit_id, (today + timedelta(days=90)).isoformat())).fetchall()
        result = []
        for row in lots:
            days = (date.fromisoformat(row["expiration_date"]) - today).days
            if days <= 90:
                result.append({"type": "expiry", "severity": "expired" if days < 0 else "critical" if days <= 30 else "warning" if days <= 60 else "notice", "days_remaining": days, **dict(row)})
        stock = db.execute("""
                 SELECT m.id AS medicine_id, m.name AS medicine_name, m.concentration, m.dosage_form, m.presentation,
                     m.administration_route, m.minimum_stock, m.stock_unit,
                   COALESCE(SUM(l.quantity),0) AS stock
            FROM medicines m LEFT JOIN lots l ON l.medicine_id=m.id AND l.unit_id=?
            WHERE m.active=1 AND m.minimum_stock>0 GROUP BY m.id
        """, (unit_id,)).fetchall()
        for row in stock:
            if row["stock"] < row["minimum_stock"]:
                result.append({"type": "low_stock", "severity": "critical" if row["stock"] == 0 else "warning", **dict(row), "recommended_restock": max(row["minimum_stock"] * 2 - row["stock"], 0)})
        return sorted(result, key=lambda item: (0 if item["severity"] in ("expired", "critical") else 1, item.get("days_remaining", 999), item["medicine_name"]))

    def do_POST(self):
        path = urlparse(self.path).path
        db = None
        try:
            payload = self.read_json()
            if path == "/api/login":
                self.login(payload)
                return
            user = self.get_user()
            self.require_csrf(user)
            if path == "/api/logout":
                token = self.cookie_value()
                db = connect_db()
                db.execute("DELETE FROM sessions WHERE token_hash = ?", (hashlib.sha256(token.encode()).hexdigest(),))
                db.commit()
                db.close()
                self.send_json(200, {"ok": True}, {"Set-Cookie": f"{COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"})
                return
            if path == "/api/password":
                current = payload.get("current_password", "")
                new_password = payload.get("new_password", "")
                if not isinstance(current, str) or not isinstance(new_password, str) or len(new_password) < 12 or len(new_password) > 256:
                    raise ApiError(400, "A nova senha deve ter entre 12 e 256 caracteres.")
                db = connect_db()
                account = db.execute("SELECT password_hash FROM users WHERE id=?", (user["id"],)).fetchone()
                if not account or not verify_password(current, account["password_hash"]):
                    db.close()
                    raise ApiError(400, "A senha atual está incorreta.")
                token_hash = hashlib.sha256(self.cookie_value().encode()).hexdigest()
                db.execute("UPDATE users SET password_hash=? WHERE id=?", (password_hash(new_password), user["id"]))
                db.execute("DELETE FROM sessions WHERE user_id=? AND token_hash<>?", (user["id"], token_hash))
                db.commit()
                db.close()
                self.send_json(200, {"ok": True})
                return
            db = connect_db()
            unit_id = self.get_unit_id(db, user)
            if path == "/api/medicines":
                result = self.create_medicine(db, user, payload)
            elif path == "/api/entries":
                result = self.create_entry(db, user, unit_id, payload)
            elif path == "/api/exits":
                result = self.create_exit(db, user, unit_id, payload)
            elif path == "/api/inventory":
                result = self.create_inventory_adjustment(db, user, unit_id, payload)
            elif path == "/api/users":
                result = self.create_user(db, user, payload)
            elif path.startswith("/api/users/"):
                result = self.update_user(db, user, path.rsplit("/", 1)[1], payload)
            elif path == "/api/units":
                result = self.create_unit(db, user, payload)
            elif path == "/api/transfers":
                result = self.create_transfer(db, user, unit_id, payload)
            elif path.startswith("/api/transfers/"):
                result = self.transfer_action(db, user, unit_id, path, payload)
            else:
                raise ApiError(404, "Rota não encontrada.")
            db.close()
            self.send_json(201, result)
        except ApiError as error:
            self.send_error_json(error)
        except sqlite3.IntegrityError as error:
            self.send_json(409, {"error": "Registro duplicado ou referência inválida."})
        except Exception:
            self.send_json(500, {"error": "Erro interno. Consulte o log do servidor."})
        finally:
            if db is not None:
                db.close()

    def do_PUT(self):
        path = urlparse(self.path).path
        db = None
        try:
            payload = self.read_json() if int(self.headers.get("Content-Length", "0")) > 0 else {}
            user = self.get_user()
            self.require_csrf(user)
            if not path.startswith("/api/medicines/"):
                raise ApiError(404, "Rota não encontrada.")
            medicine_id = path.rsplit("/", 1)[1]
            db = connect_db()
            result = self.update_medicine(db, user, medicine_id, payload)
            db.close()
            self.send_json(200, result)
        except ApiError as error:
            self.send_error_json(error)
        except sqlite3.IntegrityError:
            self.send_json(409, {"error": "Registro duplicado ou referência inválida."})
        except Exception:
            self.send_json(500, {"error": "Erro interno. Consulte o log do servidor."})
        finally:
            if db is not None:
                db.close()

    def do_DELETE(self):
        path = urlparse(self.path).path
        db = None
        try:
            payload = self.read_json() if int(self.headers.get("Content-Length", "0")) > 0 else {}
            user = self.get_user()
            self.require_csrf(user)
            if not path.startswith("/api/medicines/"):
                raise ApiError(404, "Rota não encontrada.")
            medicine_id = path.rsplit("/", 1)[1]
            db = connect_db()
            result = self.delete_medicine(db, user, medicine_id, payload)
            db.close()
            self.send_json(200, result)
        except ApiError as error:
            self.send_error_json(error)
        except Exception:
            self.send_json(500, {"error": "Erro interno. Consulte o log do servidor."})
        finally:
            if db is not None:
                db.close()

    def create_user(self, db, actor, payload):
        if actor["role"] != "Administrador":
            raise ApiError(403, "Apenas administradores podem criar usuários.")
        username = clean_text(payload.get("username"), "o usuário", 80, True).lower()
        full_name = clean_text(payload.get("full_name"), "o nome completo", 180, True)
        email = self.clean_email(payload.get("email", ""))
        password = payload.get("password", "")
        role = clean_text(payload.get("role"), "o perfil", 40, True)
        if role not in ROLES:
            raise ApiError(400, "Perfil de usuário inválido.")
        if not isinstance(password, str) or len(password) < 12 or len(password) > 256:
            raise ApiError(400, "A senha deve ter entre 12 e 256 caracteres.")
        unit_ids = self.valid_unit_ids(db, payload.get("unit_ids"), required=role != "Administrador")
        cursor = db.execute("""INSERT INTO users(username, full_name, email, password_hash, role, active, created_at)
            VALUES (?, ?, ?, ?, ?, 1, ?)""", (username, full_name, email, password_hash(password), role, now_iso()))
        self.replace_user_units(db, cursor.lastrowid, unit_ids)
        db.commit()
        return {"id": cursor.lastrowid, "username": username, "full_name": full_name, "email": email, "role": role}

    def create_unit(self, db, actor, payload):
        if actor["role"] != "Administrador":
            raise ApiError(403, "Apenas administradores podem cadastrar unidades.")
        name = clean_text(payload.get("name"), "o nome da USF", 180, True)
        cursor = db.execute("INSERT INTO units(name, created_at) VALUES (?, ?)", (name, now_iso()))
        db.commit()
        return {"id": cursor.lastrowid, "name": name}

    def update_user(self, db, actor, raw_id, payload):
        if actor["role"] != "Administrador":
            raise ApiError(403, "Apenas administradores podem editar usuários.")
        user_id = positive_int(raw_id, "Usuário")
        target = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if not target:
            raise ApiError(404, "Usuário não encontrado.")
        if user_id == actor["id"] and (payload.get("active") is False or payload.get("role") not in (None, "Administrador")):
            raise ApiError(400, "Você não pode desativar ou rebaixar sua própria conta.")
        username = clean_text(payload.get("username", target["username"]), "o usuário", 80, True).lower()
        full_name = clean_text(payload.get("full_name", target["full_name"]), "o nome completo", 180, True)
        email = self.clean_email(payload.get("email", target["email"]))
        role = clean_text(payload.get("role", target["role"]), "o perfil", 40, True)
        if role not in ROLES:
            raise ApiError(400, "Perfil de usuário inválido.")
        active = 1 if payload.get("active", bool(target["active"])) else 0
        if not active and target["active"] and target["role"] == "Administrador":
            administrators = db.execute("SELECT COUNT(*) AS total FROM users WHERE role='Administrador' AND active=1 AND id<>?", (user_id,)).fetchone()["total"]
            if administrators == 0:
                raise ApiError(400, "Não é possível desativar o último administrador ativo.")
        new_password = payload.get("password")
        if new_password is not None:
            if not isinstance(new_password, str) or len(new_password) < 12 or len(new_password) > 256:
                raise ApiError(400, "A senha deve ter entre 12 e 256 caracteres.")
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (password_hash(new_password), user_id))
            db.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
        unit_ids = self.valid_unit_ids(db, payload.get("unit_ids"), required=role != "Administrador") if "unit_ids" in payload else None
        db.execute("UPDATE users SET username=?, full_name=?, email=?, role=?, active=? WHERE id=?", (username, full_name, email, role, active, user_id))
        if unit_ids is not None:
            self.replace_user_units(db, user_id, unit_ids)
        db.commit()
        return {"id": user_id, "username": username, "full_name": full_name, "email": email, "role": role, "active": active}

    def clean_email(self, value):
        email = clean_text(value, "o e-mail", 180)
        if email and (parseaddr(email)[1] != email or "@" not in email):
            raise ApiError(400, "Informe um endereço de e-mail válido.")
        return email

    def valid_unit_ids(self, db, raw_ids, required=False):
        if raw_ids is None:
            raw_ids = []
        if not isinstance(raw_ids, list):
            raise ApiError(400, "Unidades inválidas.")
        try:
            unit_ids = sorted(set(int(value) for value in raw_ids))
        except (TypeError, ValueError):
            raise ApiError(400, "Unidades inválidas.")
        if any(value < 1 for value in unit_ids):
            raise ApiError(400, "Unidades inválidas.")
        found = {row["id"] for row in db.execute("SELECT id FROM units WHERE id IN (%s)" % ",".join("?" * len(unit_ids)), unit_ids).fetchall()} if unit_ids else set()
        if found != set(unit_ids):
            raise ApiError(400, "Uma ou mais unidades não foram encontradas.")
        if required and not unit_ids:
            raise ApiError(400, "Vincule pelo menos uma unidade a este perfil.")
        return unit_ids

    def replace_user_units(self, db, user_id, unit_ids):
        db.execute("DELETE FROM user_units WHERE user_id=?", (user_id,))
        if unit_ids:
            db.executemany("INSERT INTO user_units(user_id, unit_id) VALUES (?, ?)", [(user_id, unit_id) for unit_id in unit_ids])

    def login(self, payload):
        username = clean_text(payload.get("username"), "usuário", 80, True)
        password = payload.get("password", "")
        if not isinstance(password, str) or len(password) > 256:
            raise ApiError(400, "Credenciais inválidas.")
        db = connect_db()
        row = db.execute("SELECT * FROM users WHERE username = ? AND active = 1", (username,)).fetchone()
        if not row or not verify_password(password, row["password_hash"]):
            db.close()
            raise ApiError(401, "Usuário ou senha incorretos.")
        raw_token = secrets.token_urlsafe(32)
        csrf = secrets.token_urlsafe(32)
        expires = (datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)).isoformat(timespec="seconds")
        db.execute("DELETE FROM sessions WHERE expires_at < ?", (now_iso(),))
        db.execute("INSERT INTO sessions(token_hash, csrf_token, user_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?)",
                   (hashlib.sha256(raw_token.encode()).hexdigest(), csrf, row["id"], expires, now_iso()))
        db.commit()
        db.close()
        secure = "; Secure" if os.environ.get("FARMACIA_SECURE_COOKIE") == "1" else ""
        self.send_json(200, {"ok": True}, {"Set-Cookie": f"{COOKIE_NAME}={raw_token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_DAYS * 86400}{secure}"})

    def create_medicine(self, db, user, payload):
        if user["role"] not in ("Administrador", "Enfermeiro"):
            raise ApiError(403, "Seu perfil não pode cadastrar medicamentos.")
        name = clean_text(payload.get("name"), "o nome do medicamento", 180, True)
        code = "MED-" + secrets.token_hex(5).upper()
        minimum = positive_int(payload.get("minimum_stock", 0), "Estoque mínimo", True)
        stock_unit = clean_text(payload.get("stock_unit"), "a unidade de estoque", 40, True)
        values = [name, "", clean_text(payload.get("concentration"), "concentração", 100), clean_text(payload.get("dosage_form"), "forma farmacêutica", 120),
                  clean_text(payload.get("presentation"), "apresentação / embalagem", 100), stock_unit,
              None, "", stock_unit,
                  clean_text(payload.get("administration_route"), "via de administração", 80),
              "Geral", code,
                  clean_text(payload.get("manufacturer_barcode"), "código de barras", 100), minimum,
                  clean_text(payload.get("notes"), "observações", 1000), now_iso()]
        cursor = db.execute("""INSERT INTO medicines(name,active_ingredient,concentration,dosage_form,presentation,unit,package_quantity,package_unit,stock_unit,administration_route,category,code,manufacturer_barcode,minimum_stock,notes,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", values)
        db.commit()
        return {"id": cursor.lastrowid, "code": code, "name": name}

    def update_medicine(self, db, user, raw_id, payload):
        if user["role"] not in ("Administrador", "Enfermeiro"):
            raise ApiError(403, "Seu perfil não pode editar medicamentos.")
        medicine_id = positive_int(raw_id, "Medicamento")
        row = db.execute("SELECT * FROM medicines WHERE id=? AND active=1", (medicine_id,)).fetchone()
        if not row:
            raise ApiError(404, "Medicamento não encontrado.")
        new_name = clean_text(payload.get("name", row["name"]), "o nome do medicamento", 180, True)
        new_code = row["code"]
        minimum = positive_int(payload.get("minimum_stock", row["minimum_stock"]), "Estoque mínimo", True)
        stock_unit = clean_text(payload.get("stock_unit", row["stock_unit"]), "a unidade de estoque", 40, True)
        db.execute("""UPDATE medicines SET
            name=?, active_ingredient=?, concentration=?, dosage_form=?, presentation=?, unit=?, package_quantity=?, package_unit=?, stock_unit=?, administration_route=?, category=?, code=?, manufacturer_barcode=?, minimum_stock=?, notes=?
            WHERE id=?""",
            (
                new_name,
                row["active_ingredient"],
                clean_text(payload.get("concentration", row["concentration"]), "concentração", 100),
                clean_text(payload.get("dosage_form", row["dosage_form"]), "forma farmacêutica", 120),
                clean_text(payload.get("presentation", row["presentation"]), "apresentação / embalagem", 100),
                stock_unit,
                row["package_quantity"],
                row["package_unit"],
                stock_unit,
                clean_text(payload.get("administration_route", row["administration_route"]), "via de administração", 80),
                row["category"],
                new_code,
                clean_text(payload.get("manufacturer_barcode", row["manufacturer_barcode"]), "código de barras", 100),
                minimum,
                clean_text(payload.get("notes", row["notes"]), "observações", 1000),
                medicine_id,
            ))
        db.commit()
        return {"id": medicine_id, "code": new_code, "name": new_name}

    def delete_medicine(self, db, user, raw_id, payload):
        if user["role"] not in ("Administrador", "Enfermeiro"):
            raise ApiError(403, "Seu perfil não pode excluir medicamentos.")
        medicine_id = positive_int(raw_id, "Medicamento")
        row = db.execute("SELECT * FROM medicines WHERE id=? AND active=1", (medicine_id,)).fetchone()
        if not row:
            raise ApiError(404, "Medicamento não encontrado.")
        db.execute("UPDATE medicines SET active=0 WHERE id=?", (medicine_id,))
        db.commit()
        return {"id": medicine_id, "deleted": True, "name": row["name"]}

    def create_entry(self, db, user, unit_id, payload):
        if not can_manage(user):
            raise ApiError(403, "Seu perfil não pode registrar entradas.")
        medicine_id = positive_int(payload.get("medicine_id"), "Medicamento")
        quantity = positive_int(payload.get("quantity"), "Quantidade")
        lot_number = clean_text(payload.get("lot_number"), "o número do lote", 100, True)
        expiry = checked_date(payload.get("expiration_date"), "Validade")
        manufacture = payload.get("manufacture_date")
        manufacture = checked_date(manufacture, "Data de fabricação") if manufacture else None
        medicine = db.execute("SELECT id, stock_unit FROM medicines WHERE id=? AND active=1", (medicine_id,)).fetchone()
        if not medicine:
            raise ApiError(404, "Medicamento não encontrado ou inativo.")
        if expiry < date.today().isoformat():
            raise ApiError(400, "Não é possível receber um lote vencido.")
        db.execute("BEGIN IMMEDIATE")
        lot = db.execute("SELECT * FROM lots WHERE unit_id=? AND medicine_id=? AND lot_number=?", (unit_id, medicine_id, lot_number)).fetchone()
        if lot and lot["expiration_date"] != expiry:
            raise ApiError(409, "O lote já existe com outra validade; confira o cadastro antes de receber.")
        if lot:
            lot_id, before = lot["id"], lot["quantity"]
            db.execute("UPDATE lots SET quantity=quantity+? WHERE id=?", (quantity, lot_id))
        else:
            cursor = db.execute("INSERT INTO lots(unit_id,medicine_id,lot_number,internal_code,manufacture_date,expiration_date,quantity,created_at) VALUES(?,?,?,?,?,?,0,?)",
                (unit_id, medicine_id, lot_number, "PENDING", manufacture, expiry, now_iso()))
            lot_id, before = cursor.lastrowid, 0
            internal = f"UBS-{medicine_id:06d}-{lot_id:06d}"
            db.execute("UPDATE lots SET internal_code=?, quantity=? WHERE id=?", (internal, quantity, lot_id))
        after = before + quantity
        self.insert_movement(db, unit_id, medicine_id, lot_id, user["id"], "Entrada", quantity, before, after, payload)
        db.commit()
        return {"lot_id": lot_id, "stock_before": before, "quantity": quantity, "stock_after": after, "stock_unit": medicine["stock_unit"]}

    def create_exit(self, db, user, unit_id, payload):
        if not can_manage(user):
            raise ApiError(403, "Seu perfil não pode registrar saídas.")
        medicine_id = positive_int(payload.get("medicine_id"), "Medicamento")
        quantity = positive_int(payload.get("quantity"), "Quantidade")
        reason = clean_text(payload.get("reason"), "o motivo", 100, True)
        lot_id = payload.get("lot_id")
        db.execute("BEGIN IMMEDIATE")
        if lot_id:
            lot = db.execute("SELECT * FROM lots WHERE id=? AND unit_id=? AND medicine_id=?", (positive_int(lot_id, "Lote"), unit_id, medicine_id)).fetchone()
            if not lot:
                raise ApiError(404, "Lote não encontrado nesta unidade.")
        else:
            lot = db.execute("SELECT * FROM lots WHERE unit_id=? AND medicine_id=? AND quantity>0 AND expiration_date>=? ORDER BY expiration_date,id LIMIT 1",
                             (unit_id, medicine_id, date.today().isoformat())).fetchone()
            if not lot:
                raise ApiError(409, "Não há lote válido disponível para saída.")
        if lot["expiration_date"] < date.today().isoformat():
            raise ApiError(409, "Saídas de lotes vencidos estão bloqueadas.")
        if quantity > lot["quantity"]:
            raise ApiError(409, f"Estoque insuficiente no lote {lot['lot_number']}. Disponível: {lot['quantity']}.")
        before, after = lot["quantity"], lot["quantity"] - quantity
        db.execute("UPDATE lots SET quantity=? WHERE id=?", (after, lot["id"]))
        self.insert_movement(db, unit_id, medicine_id, lot["id"], user["id"], "Saída", quantity, before, after, payload)
        db.commit()
        stock_unit = db.execute("SELECT stock_unit FROM medicines WHERE id=?", (medicine_id,)).fetchone()["stock_unit"]
        return {"lot_id": lot["id"], "lot_number": lot["lot_number"], "stock_before": before, "quantity": quantity, "stock_after": after, "stock_unit": stock_unit}

    def create_inventory_adjustment(self, db, user, unit_id, payload):
        if user["role"] not in ("Administrador", "Enfermeiro"):
            raise ApiError(403, "Seu perfil não pode ajustar o inventário.")
        lot_id = positive_int(payload.get("lot_id"), "Lote")
        counted = positive_int(payload.get("counted_quantity"), "Quantidade contada", True)
        reason = clean_text(payload.get("reason"), "o motivo", 240, True)
        db.execute("BEGIN IMMEDIATE")
        lot = db.execute("SELECT * FROM lots WHERE id=? AND unit_id=?", (lot_id, unit_id)).fetchone()
        if not lot:
            raise ApiError(404, "Lote não encontrado nesta unidade.")
        before, difference = lot["quantity"], counted - lot["quantity"]
        db.execute("INSERT INTO inventory_counts(unit_id,lot_id,user_id,system_quantity,counted_quantity,difference,reason,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                   (unit_id, lot_id, user["id"], before, counted, difference, reason, clean_text(payload.get("notes"), "observações", 1000), now_iso()))
        if difference:
            db.execute("UPDATE lots SET quantity=? WHERE id=?", (counted, lot_id))
            self.insert_movement(db, unit_id, lot["medicine_id"], lot_id, user["id"], "Ajuste", abs(difference), before, counted,
                                 {"reason": reason, "notes": payload.get("notes", ""), "responsible": user["full_name"]})
        db.commit()
        stock_unit = db.execute("SELECT m.stock_unit FROM medicines m JOIN lots l ON l.medicine_id=m.id WHERE l.id=?", (lot_id,)).fetchone()["stock_unit"]
        return {"lot_id": lot_id, "stock_before": before, "counted_quantity": counted, "difference": difference, "stock_after": counted, "stock_unit": stock_unit}

    def insert_movement(self, db, unit_id, medicine_id, lot_id, user_id, kind, quantity, before, after, payload):
        db.execute("""INSERT INTO movements(unit_id,medicine_id,lot_id,user_id,kind,quantity,stock_before,stock_after,reason,destination,source,document,responsible,notes,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                unit_id, medicine_id, lot_id, user_id, kind, quantity, before, after,
                clean_text(payload.get("reason"), "motivo", 240), clean_text(payload.get("destination"), "destino", 180),
                clean_text(payload.get("source"), "origem", 180), clean_text(payload.get("document"), "documento", 120),
                clean_text(payload.get("responsible"), "responsável", 180) or "", clean_text(payload.get("notes"), "observações", 1000), now_iso()))


if __name__ == "__main__":
    initialize_db()
    host = os.environ.get("FARMACIA_HOST", "127.0.0.1")
    port = int(os.environ.get("FARMACIA_PORT", "8000"))
    print(f"Farmácia UBS disponível em http://{host}:{port}")
    ThreadingHTTPServer((host, port), PharmacyHandler).serve_forever()   